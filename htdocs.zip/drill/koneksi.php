<?php
$server = "localhost";
$username = "root";
$password = "";
$db = "lapor_iqbal";

$conn = new mysqli("$server", "$username", "$password", "$db");
?>